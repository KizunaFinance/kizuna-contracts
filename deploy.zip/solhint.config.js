module.exports = require('@layerzerolabs/solhint-config');
